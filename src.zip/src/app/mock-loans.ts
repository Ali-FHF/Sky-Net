import {Loan} from './loan';


 export const LOANSDATA: Loan[] = [
  { phone: '617-562-9899',policy: 11345345, insuranceUnderwriter: 'Greg House',insuranceBrokerage: 'Gateway One', policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' },
  { phone: '617-498-9899',policy: 123543, insuranceUnderwriter: 'Narco',insuranceBrokerage: 'Gateway One', policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' },
  { phone: '617-298-9899',policy: 14533, insuranceUnderwriter: 'Bombasto', insuranceBrokerage: 'Gateway One',policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' },
  { phone: '617-889-9899',policy: 134534, insuranceUnderwriter: 'Celeritas',insuranceBrokerage: 'Gateway One', policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' },
  { phone: '617-389-9899',policy: 1345435, insuranceUnderwriter: 'Magneta' ,insuranceBrokerage: 'Gateway One',policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' },
  { phone: '617-562-9899',policy: 134356, insuranceUnderwriter: 'RubberMan',insuranceBrokerage: 'Gateway One', policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' },
  { phone: '617-267-9899',policy: 134537, insuranceUnderwriter: 'Dynama',insuranceBrokerage: 'Gateway One', policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' },
  { phone: '617-467-9899',policy: 13458, insuranceUnderwriter: 'Dr IQ', insuranceBrokerage: 'Gateway One',policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' },
  { phone: '617-562-9899',policy: 13459, insuranceUnderwriter: 'Magma',insuranceBrokerage: 'Gateway One', policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' },
  { phone: '408-763-8733',policy: 2330, insuranceUnderwriter: 'Tornado',insuranceBrokerage: 'Gateway One', policyNotes: 'Te molestie suavitate forensibus his, vim tation sententiae scriptorem cu. Rebum exerci ei pro.' }
];
