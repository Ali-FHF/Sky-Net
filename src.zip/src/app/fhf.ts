export class FHFUser {
	
	constructor(

		public userid: string, 
		public login_url: string
	
	){}
   }