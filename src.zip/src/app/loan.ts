export class Loan {

	insuranceBrokerage: string; 
	phone: string; 
	insuranceUnderwriter: string; 
	policy: number; 
	policyNotes: string; 

}




