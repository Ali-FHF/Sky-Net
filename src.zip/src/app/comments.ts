// export class Comment {
	
// 	constructor(

// 		public id: string, 
// 		public name: string, 
// 		public email: string, 
// 		public body: string
// 	){}
//    }